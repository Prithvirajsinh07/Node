module.exports.setFlash = (req, res , next) => {
res.local.flash = {
    success : req.flash("success"),
    error : req.flash("error"),
};
next();
};